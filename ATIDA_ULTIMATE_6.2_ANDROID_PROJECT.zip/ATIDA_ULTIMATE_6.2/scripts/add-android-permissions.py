from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
if not p.exists():
    raise SystemExit('AndroidManifest.xml was not generated')
s = p.read_text()
permissions = [
    '    <uses-permission android:name="android.permission.INTERNET" />',
    '    <uses-permission android:name="android.permission.RECORD_AUDIO" />',
    '    <uses-permission android:name="android.permission.CAMERA" />',
    '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />'
]
for item in permissions:
    name = item.split('"')[1]
    if name not in s:
        s = s.replace('<application', item + '\n    <application', 1)
p.write_text(s)
print('Added ATIDA manifest permission declarations.')
