# ATIDA ULTIMATE 6.2

A fresh Capacitor Android project for the ATIDA ULTIMATE 6.2 assistant.

## Build on GitHub using an Android phone

1. Create a GitHub repository and upload the **contents** of this folder (not just the ZIP archive).
2. Keep the `.github/workflows/build.yml` path intact.
3. Commit the files to `main`.
4. Open the repository's **Actions** tab and select **Build ATIDA ULTIMATE 6.2 APK**.
5. When the workflow succeeds, open the run and download `ATIDA-ULTIMATE-6.2-DEBUG-APK` from Artifacts.
6. Extract the artifact ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installation from your browser/file manager.

The workflow installs the Capacitor packages, generates the native Android project and Gradle wrapper, syncs the web app, builds the debug APK, and uploads it. You do not need to upload a pre-generated `android/` folder or `gradlew` file.

## Included features

- JARVIS-inspired holographic interface and animated reactor core
- Five themes: Futuristic, Vintage, Transformers, Neon, Titanium
- Custom accent colour and assistant display name
- Time-aware greeting and speech output where supported
- Foreground speech recognition where supported
- Music console with local audio file selection and playback controls
- Mission planner with explicit approval/denial and local activity log
- Camera preview request and Android permission declarations
- Security guidance and biometric integration foundation

## Honest capability notes

This is a working starter application, not a fully autonomous system. The command console currently handles a small set of local commands. General AI answers require connecting a secure backend. The music console plays files the user selects; background media service, media-library indexing and Bluetooth routing need native implementation and testing. Camera preview depends on WebView/Android permission support. Biometric authentication, lock-screen control, face recognition for device unlocking, malware scanning, hacker blocking, and arbitrary phone actions are **not implemented** by this starter. Android does not allow ordinary apps to take over the system lock screen or replace system biometrics. Missions are recorded for review and approval; approving one does not execute a phone action.

Never put an AI provider API key in the HTML, repository, or APK. Use a secure server-side backend.
